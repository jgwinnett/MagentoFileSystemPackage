<?php
/**
 * MagPleasure Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.magpleasure.com/LICENSE.txt
 *
 * @category   Magpleasure
 * @package    Magpleasure_Filesystem
 * @copyright  Copyright (c) 2011 Magpleasure Co. (http://www.magpleasure.com)
 * @license    http://www.magpleasure.com/LICENSE.txt
 */
$installer = $this;

$installer->startSetup();
$installer->endSetup(); 